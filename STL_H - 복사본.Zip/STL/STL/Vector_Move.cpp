/* 4�� 7�� (��)
*

*/

#include <iostream>
#include <vector>
#include "STRING.h"
using namespace std;
extern bool ����;

int main()
{
	���� = true;
	vector<STRING> v;
	v.push_back("1");
	v.push_back("12");

	/*cout << endl;
	vector<STRING> o(make_move_iterator(v.begin()), make_move_iterator(v.end()));
	for (auto i = o.begin(); i != o.end(); ++i)
		cout <<" "<< * i<<endl;*/
	


}