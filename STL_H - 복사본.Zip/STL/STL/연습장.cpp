#include <iostream>
#include "save.h"


using namespace std;

template <class R>
void change(R& _a, R& _b) {
	R temp{ _a };
	_a = _b;
	_b = temp;

}

void change(string& _a, string& _b)
{
	string temp{ _a };
	_a = _b;
	_b = temp;
}

int main()
{
	{
		int a{ 1 }, b{ 3 };
		change(a, b);
		cout << a << b << endl;

	}

	{
		string a{ "1" }, b{ "3" };
		change(a, b);
		cout << a << b << endl;
	}
	
}