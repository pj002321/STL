﻿#include <iostream>
#include <vector>
#include "STRING.h"
using namespace std;

/*							< Vector >
* insert() 쓰기
" 4444" 앞에 "333"을 끼워넣어라
  벡터에 끼워넣는짓은 무식한 짓이다.- > List를 활용해야 맞는 것
  메모리를 확보하고 이동하는데 너무 많은 행동이 필요하다.

  한줄정리 :  벡터는 마지막 위치에 추가하는데 특화 되어있다. (O(1))
					요소는 연속적으로 저장됩니다 [contiguously]
					랜덤 액세스 - 상수 𝓞(1) -> Amortized constant
					
*/

extern bool 관찰;
int main()
{
	// -	-	-	-	-	-	-	-	-	-	-	-	-	-	-	-	-	-	-	->내가 해본 코드
	vector<STRING> v{"1","22","4444","55555"};	
	v.insert(v.begin() + 2, "333");
	for (int j=0;j< v.size(); ++j)
		cout << v[j]<<endl;

	cout << endl;

	//  -	-	-	-	-	-	-	-	-	-	-	-	-	-	-	-	-	-	-	->교수님 코드
	vector<STRING> o{ "1","22","4444","55555" };

	관찰 = true;
	o.insert(o.cbegin()+=2, "333");
	관찰 = false;

	for (int j = 0; j < o.size(); ++j)
		cout << o[j] << endl;


}